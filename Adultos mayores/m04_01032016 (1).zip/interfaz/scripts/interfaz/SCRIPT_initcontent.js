﻿// ========================================================================================================
//
// 		SCRIPT GENÉRICO DE INICIO DE CONTENIDO
//
//
//		Version: 1.0
//		Autor  : AJPG
//		Fecha  : 2/3/2012
//
// ========================================================================================================


	// Iniciamos el lanzador por medio del método seleccionado CFGLauncher definido en utl_initcontent
	if(CFGLauncher)	window.location="launcher.htm?SCO="+SCO;
	else window.location="interfaz.html?SCO="+SCO;
	//abrircurso("interfaz.htm?SCO=" + SCO);