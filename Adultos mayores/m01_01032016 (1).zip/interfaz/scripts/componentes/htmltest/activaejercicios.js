//alert("activa ejercicios")
//prueba("sdfdsfsdf")
inicializarCuestionarios()
